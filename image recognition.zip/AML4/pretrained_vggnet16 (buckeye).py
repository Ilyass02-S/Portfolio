# -*- coding: utf-8 -*-
"""

@author: abhilash
"""

import os
from keras.applications import VGG16
from keras.applications import imagenet_utils
from tensorflow.keras.preprocessing.image import img_to_array, load_img
from keras.applications.inception_v3 import preprocess_input
import numpy as np
import cv2

folder_path = 'images/buckeye'
lakeside=0
buckeye=0
valley=0
# Iterate through each file in the folder
for filename in os.listdir(folder_path):
    if filename.endswith('.jpg') or filename.endswith('.jpeg') or filename.endswith('.png'):
        # Get the image path
        img_path = os.path.join(folder_path, filename)
        img = load_img(img_path)
        # Load and preprocess the image
        
        #resize the image to 299x299 square shape
        img = img.resize((224,224))
        #convert the image to array
        img_array = img_to_array(img)

        #convert the image into a 4 dimensional Tensor
        #convert from (height, width, channels), (batchsize, height, width, channels)
        img_array = np.expand_dims(img_array, axis=0)

        #preprocess the input image array
        img_array = preprocess_input(img_array)
        #Load the model from internet / computer
        #approximately 96 MB
        pretrained_model = VGG16(weights="imagenet")

        #predict using predict() method
        prediction = pretrained_model.predict(img_array)

        #decode the prediction
        actual_prediction = imagenet_utils.decode_predictions(prediction)

        print("predicted object is:")
        print(actual_prediction[0][0][1])
        print("with accuracy")
        print(actual_prediction[0][0][2]*100)
        if "lakeside" in actual_prediction[0][0][1]:
            lakeside+=1
        if "buckeye" in actual_prediction[0][0][1]:
            buckeye+=1
        if "valley" in actual_prediction[0][0][1]:
            valley+=1

        #display image and the prediction text over it
        disp_img = cv2.imread(img_path)
        #display prediction text over the image
        cv2.putText(disp_img, actual_prediction[0][0][1], (20,20), cv2.FONT_HERSHEY_TRIPLEX , 0.8, (0,0,0))
        #show the image
        cv2.imshow("Prediction",disp_img)
        cv2.waitKey(1000) 
print(lakeside)
print(buckeye)
print(valley)
"""
confusion_mat = confusion_matrix(true_labels, predicted_labels)
print("Confusion Matrix:")
print(confusion_mat)

"""
